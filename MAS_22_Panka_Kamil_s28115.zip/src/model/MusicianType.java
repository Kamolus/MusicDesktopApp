package model;

public enum MusicianType {
    GUITARIST,
    DRUMMER,
    VOCALIST,
    BASSIST
}
